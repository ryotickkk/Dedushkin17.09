package second_task;

import java.util.HashMap;

public class SubjectGrades {
    String subject;
    static HashMap<String ,Integer> grades = new HashMap<>();

    public SubjectGrades(String subject){
    this.subject = subject;
    }

    public String getSubject(){
        return subject;
    }

    public static void addGrade(String studentName,Integer grade){
        grades.put(studentName,grade);
    }
    public static double calculateAverage(){
        int total = 0;
        for(Integer grade : grades.values()) {
            total += grade;
        }
        return (double) total / grades.size();
    }
}
