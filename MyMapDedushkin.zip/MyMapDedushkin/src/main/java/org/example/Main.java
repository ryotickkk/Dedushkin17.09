package org.example;

import first_task.Student;
import second_task.SubjectGrades;

public class Main {


    public static void main(String[] args) {
      /*  Student student1 = new Student("Danek", "S052");
        Student student2 = new Student("Bob", "S032");

        Student.addStudent(student1.getStudentId(), student1);
        Student.addStudent(student2.getStudentId(), student2);

        System.out.println(Student.getStudent("S032"));
       */
        SubjectGrades.addGrade("Andrew", 5);
        SubjectGrades.addGrade("Ivan", 4);
        SubjectGrades.addGrade("Olga", 2);

        SubjectGrades grades = new SubjectGrades("Math");
        double average = SubjectGrades.calculateAverage();
        System.out.println("Average grade in"+grades.getSubject()+ ": " + average);
    }
}
